import { useState } from "preact/hooks";
import preactLogo from "./assets/preact.svg";
import viteLogo from "/vite.svg";
import "./app.css";
import Hotdeals from "./Component/Landing/HotDeals/Hotdeals";

export function App() {
  return (
    <>
      <Hotdeals />
    </>
  );
}
