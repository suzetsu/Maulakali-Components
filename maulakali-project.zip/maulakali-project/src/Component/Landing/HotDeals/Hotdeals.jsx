import React from "react";
import "./hotdeals.css";

const Hotdeals = () => {
  return (
    <div className="hotdeals_container">
      <div className="hotdeals_inner">
        <div className="left_wrapper">
          <div className="deals_texts">
            <h1>HOT DEALS</h1>
            <h3>Ignite Your Savings: Hot Deals Await!</h3>
          </div>
          <div className="button_container">
            <button>Discover More</button>
          </div>
        </div>
        <div className="right_wrapper">Hello</div>
      </div>
      <div className="hotdeals_outer">
        <div className="slider_div">
          <h1>Hiiii</h1>
        </div>
      </div>
    </div>
  );
};

export default Hotdeals;
